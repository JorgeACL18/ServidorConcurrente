package Trabajo28;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class Cliente1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            InetSocketAddress dir = new InetSocketAddress("localhost", 8080);
            Socket socket = new Socket();
            socket.connect(dir);

            System.out.println("Conectando al servidor");
            System.out.println("Servidor conectado");

            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            while (true) {
                System.out.println("Escribe tu mensaje:");
                String mensaje = sc.nextLine().trim();
                out.println(mensaje);

                System.out.println("El servidor ha recibido tu mensaje");

                if (mensaje.equalsIgnoreCase("adios")) {
                    System.out.println("Saliendo del programa");
                    break;
                }
            }
            out.close();
            sc.close();
            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


