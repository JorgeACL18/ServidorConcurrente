package Trabajo28;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args) {
        ServerSocket servidor = null;
        try {
            InetSocketAddress dir = new InetSocketAddress("localhost", 8080);
            servidor = new ServerSocket();
            servidor.bind(dir);

            System.out.println("Esperando conexiones...");

            while (true) {
                Socket socket = servidor.accept();
                System.out.println("Cliente conectado: " + socket.getRemoteSocketAddress());

                Thread HCliente = new Thread(() -> {
                    BufferedReader lector = null;
                    try {
                        lector = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                        String mensaje;
                        while ((mensaje = lector.readLine()) != null) {
                            System.out.println("Mensaje recibido: " + mensaje);

                            if ("adios".equalsIgnoreCase(mensaje)) {
                                System.out.println("El cliente (" + socket.getRemoteSocketAddress() + ") ha escrito 'adios'. Cerrando conexión");
                                break;
                            }
                        }
                    } catch (IOException e) {
                        System.out.println("Error al conectar con el cliente");
                    } finally {
                        try {
                            if (lector != null) lector.close();
                            if (socket != null) socket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                HCliente.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (servidor != null) servidor.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


